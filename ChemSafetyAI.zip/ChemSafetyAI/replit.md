# ChemSense - AI Chemical Hazard Prediction Platform

## Overview
ChemSense is a full-stack AI-powered chemical hazard prediction and safety compliance tracking application built for CA3 evaluation. The platform provides professional-grade safety analysis for laboratory environments using advanced AI models.

## Purpose
- **AI Hazard Prediction**: Analyze chemical compounds using OpenAI's GPT-4 to predict safety hazards based on concentration, temperature, and experimental conditions
- **Lab Notebook**: Document experiments, observations, and research findings
- **Safety & Compliance**: Track compliance tasks, view safety protocol diagrams, and file incident reports
- **Dashboard Analytics**: Visualize hazard distributions and recent experimental activity

## Technology Stack

### Frontend
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight routing)
- **UI Components**: Shadcn UI with Radix UI primitives
- **Styling**: Tailwind CSS with modern glassmorphism design
- **State Management**: TanStack Query v5 for server state
- **Forms**: React Hook Form with Zod validation
- **Charts**: Recharts for data visualization

### Backend
- **Runtime**: Node.js with Express
- **AI Integration**: OpenAI GPT-4o via Replit AI Integrations
- **Data Storage**: In-memory storage (MemStorage) - no database required
- **Validation**: Zod schemas shared between client and server
- **API**: RESTful endpoints with TypeScript type safety

## Project Architecture

### Data Models
Located in `shared/schema.ts`:

1. **Experiments**: Chemical compound data with AI-generated hazard predictions
   - Fields: compoundName, concentration, temperature, conditions, hazardLevel, aiPrediction, recommendations
   - Hazard levels: safe, caution, danger, critical

2. **Lab Notes**: Research documentation and observations
   - Fields: title, content, tags

3. **Compliance Tasks**: Safety compliance deadline tracking
   - Fields: title, description, deadline, status

4. **Safety Reports**: Incident documentation
   - Fields: title, content, incidentDate, severity

### Design System
Modern glassmorphism aesthetic (documented in `design_guidelines.md`):

- **Colors**: Purple-to-teal gradient scheme (#8B5CF6 → #14B8A6), semantic hazard colors
- **Visual Style**: Glassmorphism with backdrop-blur effects, glass cards, gradient text
- **Typography**: Inter for UI, JetBrains Mono for chemical/technical data
- **Spacing**: Consistent 4px/8px/16px/24px grid system
- **Navigation**: Top navbar with back buttons on all non-dashboard pages
- **Effects**: Hover scale transforms, shadow enhancements, smooth transitions

### Key Features

#### 1. Dashboard (`/`)
- Hero section with gradient text and glass effects
- Statistics cards with gradient icons and colored left borders
- Bar chart visualizing hazard distribution
- Recent experiments list with hazard badges in glass containers
- Quick action grid with 4 hoverable glass cards

#### 2. Hazard Predictor (`/predictor`)
- Glass card input form with purple gradient top border
- AI-powered hazard analysis using OpenAI GPT-4o
- Two-column layout with form and results side-by-side
- Real-time prediction results in teal-bordered glass card
- Gradient "Predict Hazard Level" button with glow effect
- Back to Dashboard navigation in top navbar

#### 3. Lab Notebook (`/notebook`)
- Glass card search bar with full-text search
- Create notes via modal dialog with glass styling
- Tag-based organization with rounded glass badges
- Grid layout of note cards with hover scale effects
- Back to Dashboard navigation in top navbar

#### 4. Safety & Compliance (`/compliance`)
Three-tab interface with glassmorphism styling:
- **Compliance Tasks**: Deadline tracking with checkbox completion in glass cards
- **Safety Charts**: Three Figma-style SVG diagrams in glass-bordered containers with hover effects
  - Hazard Assessment Flowchart
  - PPE Requirements by Hazard Level
  - Risk Assessment Matrix
- **Safety Reports**: Incident documentation in grid layout with glass cards
- Back to Dashboard navigation in top navbar

## API Routes

### Experiments
- `GET /api/experiments` - List all experiments
- `POST /api/experiments/predict` - Create prediction with AI analysis

### Lab Notes
- `GET /api/lab-notes` - List all notes
- `POST /api/lab-notes` - Create note

### Compliance Tasks
- `GET /api/compliance-tasks` - List all tasks
- `POST /api/compliance-tasks` - Create task
- `PATCH /api/compliance-tasks/:id` - Update task status

### Safety Reports
- `GET /api/safety-reports` - List all reports
- `POST /api/safety-reports` - Create report

## AI Integration
The application uses OpenAI's GPT-4o model through Replit AI Integrations:
- **Model**: gpt-4o
- **Temperature**: 0.7 for balanced creativity and accuracy
- **Response Format**: Structured JSON for consistent parsing
- **Prompt Engineering**: Detailed system prompts for accurate chemical hazard assessment
- **No API Key Needed**: Charges billed to user's Replit credits

## File Structure
```
client/
  src/
    components/
      top-navbar.tsx       # Top navigation bar with back buttons
      hazard-badge.tsx     # Hazard level indicator
      theme-provider.tsx   # Dark mode support
      theme-toggle.tsx     # Theme switcher
      ui/                  # Shadcn UI components
    pages/
      dashboard.tsx        # Home/analytics page
      hazard-predictor.tsx # AI prediction interface
      lab-notebook.tsx     # Research documentation
      compliance.tsx       # Safety & compliance hub
    index.css            # Theme variables and styles
  public/
    safety-flowchart.svg   # Hazard assessment diagram
    ppe-requirements.svg   # PPE requirements chart
    risk-matrix.svg        # Risk assessment matrix

server/
  routes.ts             # API endpoint handlers
  storage.ts            # In-memory data storage

shared/
  schema.ts             # Type-safe data models
```

## Development Workflow
1. Run `npm run dev` to start both frontend (Vite) and backend (Express) servers
2. Frontend served at port 5000 (bound to 0.0.0.0)
3. Backend API available at `/api/*` routes
4. Hot module replacement enabled for rapid development

## Design Decisions

### Why In-Memory Storage?
- Faster development and testing
- No database setup complexity
- Sufficient for CA3 evaluation requirements
- Easy to migrate to persistent storage later

### Why Glassmorphism Design?
- Modern, visually appealing aesthetic that balances professionalism with approachability
- Purple-teal gradients create distinctive brand identity
- Glass effects add depth and polish to the interface
- Excellent dark mode support with backdrop-blur effects
- Smooth hover animations enhance user experience

### Why Shadcn UI?
- Accessible, customizable components
- Full TypeScript support
- Tailwind CSS integration
- Copy-paste component philosophy

## CA3 Evaluation Criteria
✅ 4+ interactive pages (Dashboard, Predictor, Notebook, Compliance)
✅ AI/ML integration (OpenAI GPT-4o hazard predictions)
✅ Professional UI design (Glassmorphism with purple-teal gradients, Shadcn components)
✅ Full-stack architecture (React + Express + TypeScript)
✅ Data visualization (Recharts bar charts, custom SVG diagrams)
✅ Form validation (React Hook Form + Zod)
✅ State management (TanStack Query)
✅ Dark mode support with glass effects
✅ Responsive design with top navigation
✅ Type safety throughout
✅ Accessible navigation with proper interactive elements
✅ Connected pages with back button navigation

## Recent Changes
- 2025-10-13: Complete frontend redesign with glassmorphism aesthetic
  - Replaced Carbon Design System with modern purple-teal gradient color scheme
  - Implemented glassmorphism effects (backdrop-blur, glass cards, gradient text)
  - Changed from sidebar to top navbar navigation
  - Added "Back to Dashboard" buttons on all non-dashboard pages
  - Enhanced all 4 pages with new layouts and hover effects
  - Fixed accessibility issues with proper non-nested interactive elements
  - Comprehensive E2E testing confirms all features work correctly
- 2025-10-13: Initial project setup with all core features
  - Created data schema with 4 entity types
  - Implemented AI hazard prediction with OpenAI GPT-4o integration
  - Built all 4 major pages with full CRUD functionality
  - Created 3 professional SVG safety diagrams
  - Set up complete frontend and backend architecture with TypeScript
